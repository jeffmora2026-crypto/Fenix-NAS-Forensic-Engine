---
name: fenix-security-skill
description: Sovereign forensic audit engine, integrity control, and anomaly analysis skill optimized for NAS environments.
version: 1.0.0
author: PHENIX
---

# Fenix Security Skill

## Overview
High-efficiency modular skill designed for real-time inspection, file integrity validation, and anomalous vector detection, operating autonomously with minimal resource consumption.

## Core Capabilities
- Forensic auditing of data structures.
- Anomaly cross-referencing and identification across directories.
- Metadata validation and integrity control.
